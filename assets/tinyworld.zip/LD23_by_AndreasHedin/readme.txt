-- Ludum Dare 23
Theme: Tiny World
A game by Andreas Hedin

Control the balloon and tower to defeat the zombies, evil birds and beasts.

-- Controls:
F: Switch between balloon and tower
WASD: Steer the balloon
Left mouse button: Fire primary weapon
Right mouse button: Fire secondary weapon

contact@andreashedin.com
andreashedin.com
